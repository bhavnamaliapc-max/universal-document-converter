import os
import shutil
import subprocess
import tempfile
import uuid
from pathlib import Path

from flask import Flask, render_template, request, send_file, jsonify, after_this_request
from werkzeug.utils import secure_filename

try:
    from PIL import Image
except ImportError:
    Image = None

try:
    import fitz  # PyMuPDF
except ImportError:
    fitz = None

try:
    from pdf2docx import Converter as PDF2DOCX
except ImportError:
    PDF2DOCX = None

BASE = Path(__file__).resolve().parent
WORK = BASE / "work"
UPLOADS = WORK / "uploads"
OUTPUTS = WORK / "outputs"
for p in (UPLOADS, OUTPUTS):
    p.mkdir(parents=True, exist_ok=True)

app = Flask(__name__)
app.config["MAX_CONTENT_LENGTH"] = 200 * 1024 * 1024  # 200 MB
app.config["SECRET_KEY"] = os.environ.get("UDC_SECRET", "local-document-converter")

ALLOWED = {
    ".pdf", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx",
    ".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff"
}

def allowed_file(name):
    return Path(name).suffix.lower() in ALLOWED

def find_soffice():
    candidates = [
        shutil.which("soffice"),
        shutil.which("libreoffice"),
        r"C:\Program Files\LibreOffice\program\soffice.exe",
        r"C:\Program Files (x86)\LibreOffice\program\soffice.exe",
    ]
    for c in candidates:
        if c and os.path.isfile(c):
            return c
    return None

def office_to_pdf(src, out_dir):
    """Convert an Office file to PDF without accidentally reusing an old PDF."""
    soffice = find_soffice()
    if not soffice:
        raise RuntimeError(
            "LibreOffice was not found. Install LibreOffice first; it is required "
            "to convert Word/Excel/PowerPoint files to PDF."
        )

    out_dir.mkdir(parents=True, exist_ok=True)
    out = out_dir / (src.stem + ".pdf")

    # Important: an old output file must never be mistaken for a new conversion.
    try:
        out.unlink(missing_ok=True)
    except OSError as exc:
        raise RuntimeError(f"Cannot replace old output file {out.name}: {exc}")

    # A unique LibreOffice profile prevents a stuck/other LO process from hijacking
    # this headless conversion on Windows.
    profile_dir = out_dir / ("lo_profile_" + uuid.uuid4().hex)
    profile_dir.mkdir(parents=True, exist_ok=True)
    cmd = [
        soffice,
        "-env:UserInstallation=" + profile_dir.resolve().as_uri(),
        "--headless", "--convert-to", "pdf",
        "--outdir", str(out_dir), str(src)
    ]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
    except subprocess.TimeoutExpired:
        raise RuntimeError("Office → PDF timed out after 180 seconds.")
    finally:
        shutil.rmtree(profile_dir, ignore_errors=True)

    details = " ".join(x.strip() for x in (proc.stdout, proc.stderr) if x and x.strip())
    if proc.returncode != 0 or not out.exists() or out.stat().st_size == 0:
        raise RuntimeError("Office → PDF failed." + (f" Details: {details}" if details else ""))

    # Validate the newly created file rather than serving a corrupt/stale result.
    if fitz is not None:
        try:
            with fitz.open(str(out)) as pdf:
                if len(pdf) == 0:
                    raise RuntimeError("The generated PDF has no pages.")
        except Exception as exc:
            out.unlink(missing_ok=True)
            raise RuntimeError(f"LibreOffice produced an invalid PDF: {exc}")
    else:
        with out.open("rb") as fh:
            if not fh.read(5).startswith(b"%PDF-"):
                out.unlink(missing_ok=True)
                raise RuntimeError("LibreOffice output is not a valid PDF file.")
    return out

def image_to_pdf(src, out_dir):
    if Image is None:
        raise RuntimeError("Pillow is not installed.")
    out = out_dir / (src.stem + ".pdf")
    with Image.open(src) as im:
        if getattr(im, "n_frames", 1) > 1:
            frames = []
            for i in range(im.n_frames):
                im.seek(i)
                frames.append(im.convert("RGB").copy())
            frames[0].save(out, "PDF", save_all=True, append_images=frames[1:])
        else:
            im.convert("RGB").save(out, "PDF")
    return out

def pdf_to_word(src, out_dir):
    if PDF2DOCX is None:
        raise RuntimeError("pdf2docx is not installed.")
    out = out_dir / (src.stem + ".docx")
    cv = PDF2DOCX(str(src))
    try:
        cv.convert(str(out))
    finally:
        cv.close()
    return out

def pdf_to_images(src, out_dir):
    if fitz is None:
        raise RuntimeError("PyMuPDF is not installed.")
    doc = fitz.open(str(src))
    created = []
    try:
        for i, page in enumerate(doc, 1):
            pix = page.get_pixmap(matrix=fitz.Matrix(2, 2), alpha=False)
            out = out_dir / f"{src.stem}_page_{i}.png"
            pix.save(str(out))
            created.append(out)
    finally:
        doc.close()
    if not created:
        raise RuntimeError("PDF has no pages.")
    return created[0]

def merge_pdfs(paths, out):
    if fitz is None:
        raise RuntimeError("PyMuPDF is not installed.")
    result = fitz.open()
    try:
        for p in paths:
            doc = fitz.open(str(p))
            result.insert_pdf(doc)
            doc.close()
        result.save(str(out))
    finally:
        result.close()
    return out

def split_pdf(src, start, end, out):
    if fitz is None:
        raise RuntimeError("PyMuPDF is not installed.")
    doc = fitz.open(str(src))
    total = len(doc)
    start = max(1, int(start))
    end = min(total, int(end))
    if start > end:
        doc.close()
        raise RuntimeError(f"Invalid page range. PDF has {total} pages.")
    new = fitz.open()
    try:
        new.insert_pdf(doc, from_page=start-1, to_page=end-1)
        new.save(str(out))
    finally:
        new.close()
        doc.close()
    return out

def compress_pdf(src, out):
    if fitz is None:
        raise RuntimeError("PyMuPDF is not installed.")
    doc = fitz.open(str(src))
    try:
        doc.save(str(out), garbage=4, deflate=True, clean=True)
    finally:
        doc.close()
    return out

def watermark_pdf(src, text, out):
    if fitz is None:
        raise RuntimeError("PyMuPDF is not installed.")
    doc = fitz.open(str(src))
    try:
        for page in doc:
            rect = page.rect
            page.insert_text(
                (rect.width / 2 - 80, rect.height / 2),
                text[:80],
                fontsize=28,
                rotate=45,
                color=(0.45, 0.45, 0.45),
                overlay=True,
            )
        doc.save(str(out), garbage=4, deflate=True)
    finally:
        doc.close()
    return out

def job_dir():
    p = OUTPUTS / uuid.uuid4().hex
    p.mkdir(parents=True, exist_ok=True)
    return p

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/api/health")
def health():
    return jsonify({
        "ok": True,
        "libreoffice": bool(find_soffice()),
        "pdf2docx": PDF2DOCX is not None,
        "pillow": Image is not None,
        "pymupdf": fitz is not None,
    })

@app.post("/api/convert")
def convert():
    target = request.form.get("target", "").strip().lower()
    uploaded = request.files.getlist("files")

    if not uploaded or not any(f.filename for f in uploaded):
        return jsonify(error="Please select at least one file."), 400

    if target not in {"pdf", "word", "images"}:
        return jsonify(error="Supported output formats are PDF, Word and Images."), 400

    job = job_dir()
    results = []
    errors = []

    for f in uploaded:
        if not f.filename:
            continue
        if not allowed_file(f.filename):
            errors.append(f"{f.filename}: unsupported file type")
            continue

        name = secure_filename(f.filename)
        src = job / name
        f.save(src)

        try:
            ext = src.suffix.lower()
            if target == "pdf":
                if ext == ".pdf":
                    out = job / f"{src.stem}_copy.pdf"
                    shutil.copy2(src, out)
                elif ext in {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff"}:
                    out = image_to_pdf(src, job)
                elif ext in {".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx"}:
                    out = office_to_pdf(src, job)
                else:
                    raise RuntimeError("This file cannot be converted to PDF.")
                results.append(out)
            elif target == "word":
                if ext == ".pdf":
                    pdf_src = src
                elif ext in {".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx"}:
                    # For PowerPoint/Excel/Word inputs: convert to PDF first, then
                    # extract the PDF content into a DOCX. This is not a perfect
                    # slide-layout conversion, but it supports Office input files.
                    intermediate = job / "intermediate_pdf"
                    intermediate.mkdir(parents=True, exist_ok=True)
                    pdf_src = office_to_pdf(src, intermediate)
                else:
                    raise RuntimeError(
                        "Word output accepts PDF, Word, Excel or PowerPoint files."
                    )
                results.append(pdf_to_word(pdf_src, job))
            else:
                if ext == ".pdf":
                    results.append(pdf_to_images(src, job))
                elif ext in {".jpg", ".jpeg", ".png", ".webp", ".bmp", ".tif", ".tiff"}:
                    out = job / f"{src.stem}.png"
                    with Image.open(src) as im:
                        im.convert("RGBA" if "A" in im.getbands() else "RGB").save(out, "PNG")
                    results.append(out)
                else:
                    raise RuntimeError("Images output accepts PDF or image files.")
        except Exception as exc:
            errors.append(f"{f.filename}: {exc}")

    if not results and errors:
        shutil.rmtree(job, ignore_errors=True)
        return jsonify(success=0, failed=len(errors), errors=errors), 400

    # One result: direct download. Multiple: zip.
    if len(results) == 1:
        result = results[0]
        @after_this_request
        def cleanup(response):
            # Delay cleanup so Flask can finish reading the file.
            return response
        return send_file(result, as_attachment=True, download_name=result.name)

    archive = shutil.make_archive(str(job / "converted_files"), "zip", root_dir=job)
    # Remove original uploads from archive content after archive creation is not needed;
    # they are in the same job directory. Rebuild a clean archive with only output files.
    clean_zip_base = job / "converted_result"
    import zipfile
    with zipfile.ZipFile(str(clean_zip_base) + ".zip", "w", zipfile.ZIP_DEFLATED) as z:
        for p in results:
            if p.exists():
                z.write(p, arcname=p.name)
    zip_path = Path(str(clean_zip_base) + ".zip")

    return send_file(
        zip_path,
        as_attachment=True,
        download_name="converted_files.zip",
        mimetype="application/zip"
    )

@app.post("/api/merge")
def merge():
    uploaded = request.files.getlist("files")
    if len(uploaded) < 2:
        return jsonify(error="Select at least 2 PDF files to merge."), 400
    job = job_dir()
    paths = []
    try:
        for f in uploaded:
            if Path(f.filename).suffix.lower() != ".pdf":
                raise RuntimeError("Merge accepts PDF files only.")
            p = job / secure_filename(f.filename)
            f.save(p)
            paths.append(p)
        out = job / "merged.pdf"
        merge_pdfs(paths, out)
        return send_file(out, as_attachment=True, download_name="merged.pdf")
    except Exception as exc:
        return jsonify(error=str(exc)), 400

@app.post("/api/split")
def split():
    f = request.files.get("file")
    if not f or not f.filename:
        return jsonify(error="Select a PDF file."), 400
    job = job_dir()
    src = job / secure_filename(f.filename)
    f.save(src)
    try:
        start = request.form.get("start", "1")
        end = request.form.get("end", "1")
        out = job / f"{src.stem}_pages_{start}-{end}.pdf"
        split_pdf(src, start, end, out)
        return send_file(out, as_attachment=True, download_name=out.name)
    except Exception as exc:
        return jsonify(error=str(exc)), 400

@app.post("/api/compress")
def compress():
    f = request.files.get("file")
    if not f or not f.filename:
        return jsonify(error="Select a PDF file."), 400
    job = job_dir()
    src = job / secure_filename(f.filename)
    f.save(src)
    try:
        out = job / f"{src.stem}_compressed.pdf"
        compress_pdf(src, out)
        return send_file(out, as_attachment=True, download_name=out.name)
    except Exception as exc:
        return jsonify(error=str(exc)), 400

@app.post("/api/watermark")
def watermark():
    f = request.files.get("file")
    text = request.form.get("text", "CONFIDENTIAL").strip()
    if not f or not f.filename:
        return jsonify(error="Select a PDF file."), 400
    if not text:
        return jsonify(error="Enter watermark text."), 400
    job = job_dir()
    src = job / secure_filename(f.filename)
    f.save(src)
    try:
        out = job / f"{src.stem}_watermarked.pdf"
        watermark_pdf(src, text, out)
        return send_file(out, as_attachment=True, download_name=out.name)
    except Exception as exc:
        return jsonify(error=str(exc)), 400

@app.errorhandler(413)
def too_large(_):
    return jsonify(error="File is too large. Maximum upload size is 200 MB."), 413

if __name__ == "__main__":
    print("Universal Document Converter Web")
    print("Open http://127.0.0.1:5000")
    app.run(host="127.0.0.1", port=5000, debug=False)
